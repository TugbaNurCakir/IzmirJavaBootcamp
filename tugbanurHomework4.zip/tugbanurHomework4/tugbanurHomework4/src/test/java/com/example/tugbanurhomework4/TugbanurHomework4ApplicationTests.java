package com.example.tugbanurhomework4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TugbanurHomework4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
