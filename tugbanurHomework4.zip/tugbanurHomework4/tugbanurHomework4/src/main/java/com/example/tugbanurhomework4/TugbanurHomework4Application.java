package com.example.tugbanurhomework4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TugbanurHomework4Application {

    public static void main(String[] args) {
        SpringApplication.run(TugbanurHomework4Application.class, args);
    }

}
