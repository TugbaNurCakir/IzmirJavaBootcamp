package com.kodluyoruz.tugbanurhomework3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;


@SpringBootApplication
public class TugbanurHomework3Application {

    public static void main(String[] args) {
        SpringApplication.run(TugbanurHomework3Application.class, args);
    }

}
