package com.kodluyoruz.tugbanurhomework3.model.Category.Enums;

public enum Pay {
    CASH,
    CREDİT_CARD
}