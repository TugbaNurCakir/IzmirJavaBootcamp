package com.kodluyoruz.tugbanurhomework3.model.Category.Enums;

public enum Page {
    MAIN_MENU,
    SEARCHING
}