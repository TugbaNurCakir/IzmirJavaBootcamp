package com.kodluyoruz.tugbanurhomework3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TugbanurHomework3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
